import '../models.dart';

/// Limited static checks for JavaScript. User code is never executed.
class CodeInspector {
  const CodeInspector();

  static final _literalLog = RegExp(r'''^console\.log\(\s*("[^"\\]*"|'[^'\\]*'|\d+)\s*\)\s*;?$''');

  AnswerResult inspect(String code, QuestionAnalysis a) {
    if (a.language != null && a.language != 'JavaScript') {
      return AnswerResult(status: AnswerStatus.unsupported, explanation: 'فحص كود ${a.language} غير متاح.');
    }
    if (a.type == QuestionType.codeOutput) return _output(code);
    final issues = findIssues(code);
    if (issues.isEmpty) {
      return const AnswerResult(
        status: AnswerStatus.needsInformation,
        explanation: 'لم ترصد الفحوص المحدودة مشكلة. هذا لا يعني أن الكود صحيح.',
      );
    }
    return AnswerResult(
      status: AnswerStatus.answered,
      answer: issues.join('\n'),
      explanation: 'ملاحظات من فحص ثابت محدود؛ قد توجد أخطاء أخرى لم تُرصد.',
      evidence: const ['فحص نمطي ثابت دون تشغيل الكود'],
    );
  }

  /// Predicts output only when every line is a console.log of a plain literal.
  AnswerResult _output(String code) {
    final out = <String>[];
    for (final line in code.split('\n').map((l) => l.trim()).where((l) => l.isNotEmpty)) {
      final value = _literalLog.firstMatch(line)?.group(1);
      // Numbers with a leading zero or very long numbers print differently in JavaScript.
      if (value == null || RegExp(r'^(0\d+|\d{16,})$').hasMatch(value)) {
        return const AnswerResult(
          status: AnswerStatus.needsInformation,
          explanation: 'لا يمكن توقع المخرجات بثقة؛ المدعوم فقط طباعة نصوص أو أعداد صريحة.',
        );
      }
      out.add(value.startsWith('"') || value.startsWith("'") ? value.substring(1, value.length - 1) : value);
    }
    if (out.isEmpty) {
      return const AnswerResult(status: AnswerStatus.needsInformation, explanation: 'أضف الكود.');
    }
    return AnswerResult(
      status: AnswerStatus.answered,
      answer: out.join('\n'),
      explanation: 'يطبع كل استدعاء console.log قيمته في سطر مستقل.',
      evidence: const ['كل الأسطر طباعة لقيم صريحة'],
    );
  }

  List<String> findIssues(String code) {
    // Hide strings and comments so their contents do not trigger checks.
    final clean = code.replaceAll(
      RegExp(r'''"(\\.|[^"\\\n])*"|'(\\.|[^'\\\n])*'|`(\\.|[^`\\])*`|//[^\n]*|/\*[\s\S]*?\*/'''),
      '""',
    );
    final issues = <String>[];
    const pairs = {')': '(', ']': '[', '}': '{'};
    final stack = <String>[];
    var balanced = true;
    for (final ch in clean.split('')) {
      if (pairs.containsValue(ch)) stack.add(ch);
      if (pairs.containsKey(ch) && (stack.isEmpty || stack.removeLast() != pairs[ch])) {
        balanced = false;
        break;
      }
    }
    if (!balanced || stack.isNotEmpty) issues.add('الأقواس قد تكون غير متوازنة.');
    if (RegExp(r'\bif\s*\([^()=!<>]*[^=!<>]=(?![=>])[^()]*\)').hasMatch(clean)) {
      issues.add('داخل شرط if إسناد (=) وقد يكون المقصود المقارنة (===).');
    }
    if (RegExp(r'<=\s*[\w$.]+\.length\b').hasMatch(clean)) {
      issues.add('استخدام <= مع length قد يتجاوز آخر عنصر؛ جرّب <.');
    }
    return issues;
  }
}
