import '../core/text.dart';
import '../models.dart';

/// Rule-based classifier. Question format and subject domain are detected separately.
class QuestionAnalyzer {
  const QuestionAnalyzer();

  QuestionAnalysis analyze(QuestionInput q) {
    final all = '${q.text}\n${q.code}\n${q.options.join('\n')}';
    final language = _language(all);
    final programming = language != null ||
        q.code.trim().isNotEmpty ||
        containsAny(all, ['برمجة', 'برنامج', 'خوارزمية', 'كود', 'متغير', 'مصفوفة', 'دالة', 'حلقة تكرار', 'programming', 'variable', 'algorithm', 'array', 'loop']);
    final math = containsAny(all, ['رياضيات', 'معادلة', 'مثلث', 'مساحة', 'محيط', 'equation', 'triangle']);
    return QuestionAnalysis(
      type: q.manualType ?? _type(q, programming),
      domain: programming
          ? QuestionDomain.programming
          : math
              ? QuestionDomain.mathematics
              : QuestionDomain.unknown,
      language: language,
    );
  }

  String? _language(String raw) {
    final s = raw.toLowerCase();
    if (containsAny(raw, ['javascript', 'جافاسكريبت', 'جافا سكريبت']) ||
        RegExp(r'console\.log|\b(let|const|var)\s+[a-z_$][\w$]*\s*=|=>|===').hasMatch(s)) {
      return 'JavaScript';
    }
    if (containsAny(raw, ['python', 'بايثون']) || RegExp(r'\bdef\s+\w+\s*\(.*\)\s*:').hasMatch(s)) {
      return 'Python';
    }
    return null;
  }

  QuestionType _type(QuestionInput q, bool programming) {
    final t = q.text;
    bool has(List<String> p) => containsAny(t, p);
    if (has(['صح أو خطأ', 'صح أم خطأ', 'صحيحة أم خاطئة', 'true or false'])) return QuestionType.trueFalse;
    if (has(['صل بين', 'وصل بين', 'طابق', 'match the'])) return QuestionType.matching;
    if (has(['رتب', 'ترتيب الخطوات', 'put in order', 'arrange the'])) return QuestionType.ordering;
    if (q.options.length >= 2 ||
        has(['اختر الإجابة', 'حدد الإجابة', 'أي مما يلي', 'الاختيار الصحيح', 'choose the correct', 'which of the following'])) {
      return QuestionType.multipleChoice;
    }
    if (has(['أكمل الكود', 'complete the code'])) return QuestionType.codeCompletion;
    if (t.contains('___') || has(['أكمل الفراغ', 'أكمل العبارة', 'املأ الفراغ', 'fill in the blank'])) {
      return QuestionType.fillBlank;
    }
    if (programming && has(['ناتج', 'مخرجات', 'ماذا يطبع', 'output'])) return QuestionType.codeOutput;
    if (programming && has(['صحح', 'الخطأ في', 'اكتشف الخطأ', 'debug', 'find the error', 'fix the'])) {
      return QuestionType.codeDebugging;
    }
    if (q.code.trim().isNotEmpty) return QuestionType.code;
    if (has(['اشرح', 'علل', 'ناقش', 'قارن', 'explain', 'discuss', 'compare'])) return QuestionType.longAnswer;
    if (has(['ما هو', 'ما هي', 'ما وظيفة', 'ما المقصود', 'ما الفرق', 'عرف', 'اذكر', 'what is', 'what does', 'define'])) {
      return QuestionType.shortAnswer;
    }
    return QuestionType.unknown;
  }
}
