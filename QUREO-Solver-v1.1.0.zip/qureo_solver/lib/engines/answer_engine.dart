import '../core/text.dart';
import '../models.dart';
import 'code_inspector.dart';
import 'knowledge_base.dart';

/// Answers only when there is explicit local evidence; otherwise asks for more.
class AnswerEngine {
  const AnswerEngine();

  static const _filler = [
    'اختر الإجابة الصحيحة', 'حدد الإجابة الصحيحة', 'choose the correct answer',
    'في لغة javascript', 'في لغة جافاسكريبت', 'في javascript', 'في جافاسكريبت',
    'في جافا سكريبت', 'in javascript', 'في البرمجة', 'اشرح',
  ];
  static const _negations = ['ليس', 'ليست', 'لا', 'عدا', 'ماعدا', 'باستثناء', 'خطأ', 'not', 'except'];

  /// Exact match of the whole question, so extra conditions are never ignored.
  KnowledgeEntry? find(String question) {
    var s = ' ${tokens(question).join(' ')} ';
    for (final f in _filler) {
      s = s.replaceAll(' ${tokens(f).join(' ')} ', ' ');
    }
    s = s.trim();
    for (final e in knowledgeBase) {
      for (final t in [e.concept, ...e.triggers]) {
        final k = tokens(t).join(' ');
        if (s == k) return e;
      }
    }
    return null;
  }

  AnswerResult solve(QuestionInput q, QuestionAnalysis a) {
    if (q.code.trim().isNotEmpty &&
        (a.type == QuestionType.code || a.type == QuestionType.codeOutput || a.type == QuestionType.codeDebugging)) {
      return const CodeInspector().inspect(q.code, a);
    }
    // The local content is about JavaScript and general programming only.
    if (a.language != null && a.language != 'JavaScript') {
      return _need('قاعدة المعرفة الحالية لا تغطي لغة ${a.language}.');
    }
    const supported = [QuestionType.multipleChoice, QuestionType.shortAnswer, QuestionType.longAnswer, QuestionType.fillBlank];
    if (!supported.contains(a.type)) {
      return AnswerResult(
        status: AnswerStatus.unsupported,
        explanation: 'تم تصنيف السؤال (${a.type.label}) لكن حل هذا النوع غير متاح في هذا الإصدار.',
      );
    }
    final entry = find(q.text);
    if (entry == null) {
      return _need('لا توجد معلومة مطابقة في قاعدة المعرفة المحلية، لذلك لن يتم تخمين الإجابة.');
    }
    final evidence = ['${entry.id}: ${entry.concept}', KnowledgeEntry.source];
    if (a.type != QuestionType.multipleChoice) {
      return AnswerResult(status: AnswerStatus.answered, answer: entry.answer, explanation: entry.explanation, evidence: evidence);
    }
    if (q.options.length < 2) return _need('أضف اختيارين على الأقل.');
    final matches = q.options
        .where((o) => containsAny(o, entry.optionKeys) && !containsAny(o, _negations))
        .toList();
    if (matches.length != 1) {
      return _need('لا يوجد اختيار واحد فقط تدعمه قاعدة المعرفة (المطابقات: ${matches.length}).');
    }
    return AnswerResult(
      status: AnswerStatus.answered,
      answer: matches.single,
      explanation: '${entry.explanation}\nالاختيار المحدد هو الوحيد المتوافق مع: ${entry.answer}',
      evidence: evidence,
    );
  }

  AnswerResult _need(String why) => AnswerResult(status: AnswerStatus.needsInformation, explanation: why);
}
