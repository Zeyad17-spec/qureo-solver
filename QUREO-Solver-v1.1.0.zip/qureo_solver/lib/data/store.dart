import 'package:flutter/foundation.dart';
import '../models.dart';

/// Storage contract used by the UI. Notifies listeners after every change.
abstract class Store extends ChangeNotifier {
  Future<List<HistoryItem>> history();
  Future<int> add(HistoryItem item);
  Future<void> setFavorite(int id, bool value);
  Future<void> delete(int id);
  Future<void> clear();
  Future<Map<String, String>> settings();
  Future<void> setSetting(String key, String value);
}

/// Non-persistent implementation for tests.
class MemoryStore extends Store {
  final _items = <HistoryItem>[];
  final _settings = <String, String>{};
  var _nextId = 1;

  @override
  Future<List<HistoryItem>> history() async => _items.reversed.toList();

  @override
  Future<int> add(HistoryItem item) async {
    final id = _nextId++;
    _items.add(item.copyWith(id: id));
    notifyListeners();
    return id;
  }

  @override
  Future<void> setFavorite(int id, bool value) async {
    final i = _items.indexWhere((e) => e.id == id);
    if (i >= 0) _items[i] = _items[i].copyWith(favorite: value);
    notifyListeners();
  }

  @override
  Future<void> delete(int id) async {
    _items.removeWhere((e) => e.id == id);
    notifyListeners();
  }

  @override
  Future<void> clear() async {
    _items.clear();
    notifyListeners();
  }

  @override
  Future<Map<String, String>> settings() async => Map.of(_settings);

  @override
  Future<void> setSetting(String key, String value) async {
    _settings[key] = value;
    notifyListeners();
  }
}
