import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import '../models.dart';
import 'store.dart';

/// SQLite storage. Schema version 2 upgrades the 1.0 database in place.
class SqliteStore extends Store {
  Future<Database>? _db;

  Future<Database> get _open => _db ??= _create();

  Future<Database> _create() async => openDatabase(
        p.join(await getDatabasesPath(), 'qureo_solver.db'),
        version: 2,
        onCreate: (db, _) async {
          await db.execute('CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT,'
              'question TEXT NOT NULL,type TEXT NOT NULL,domain TEXT NOT NULL,status TEXT NOT NULL,'
              'answer TEXT,explanation TEXT NOT NULL,created_at TEXT NOT NULL)');
          await _toV2(db);
        },
        onUpgrade: (db, from, _) async {
          if (from < 2) await _toV2(db);
        },
      );

  Future<void> _toV2(Database db) async {
    await db.execute('ALTER TABLE history ADD COLUMN favorite INTEGER NOT NULL DEFAULT 0 CHECK(favorite IN (0,1))');
    await db.execute('CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)');
    await db.execute('CREATE INDEX idx_history_created ON history(created_at)');
  }

  @override
  Future<List<HistoryItem>> history() async =>
      (await (await _open).query('history', orderBy: 'id DESC')).map(HistoryItem.fromMap).toList();

  @override
  Future<int> add(HistoryItem item) async {
    final id = await (await _open).insert('history', item.toMap());
    notifyListeners();
    return id;
  }

  @override
  Future<void> setFavorite(int id, bool value) async {
    await (await _open).update('history', {'favorite': value ? 1 : 0}, where: 'id = ?', whereArgs: [id]);
    notifyListeners();
  }

  @override
  Future<void> delete(int id) async {
    await (await _open).delete('history', where: 'id = ?', whereArgs: [id]);
    notifyListeners();
  }

  @override
  Future<void> clear() async {
    await (await _open).delete('history');
    notifyListeners();
  }

  @override
  Future<Map<String, String>> settings() async => {
        for (final r in await (await _open).query('settings')) r['key'] as String: r['value'] as String,
      };

  @override
  Future<void> setSetting(String key, String value) async {
    await (await _open).insert('settings', {'key': key, 'value': value}, conflictAlgorithm: ConflictAlgorithm.replace);
    notifyListeners();
  }
}
