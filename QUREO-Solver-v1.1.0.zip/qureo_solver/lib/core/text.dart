/// Normalizes Arabic and English text. Apply it to both input and keywords.
String normalizeText(String input) {
  const digits = '٠١٢٣٤٥٦٧٨٩';
  var s = input.toLowerCase().replaceAll(RegExp(r'[\u064B-\u065F\u0670\u0640]'), '');
  for (var i = 0; i < digits.length; i++) {
    s = s.replaceAll(digits[i], '$i');
  }
  s = s
      .replaceAll(RegExp('[أإآ]'), 'ا')
      .replaceAll('ى', 'ي')
      .replaceAll('ة', 'ه')
      .replaceAll('ؤ', 'و')
      .replaceAll('ئ', 'ي');
  return s
      .replaceAll(RegExp(r'!(?!=)'), ' ')
      .replaceAll(RegExp(r'[^a-z0-9_\u0621-\u064A=!<>+*/%&|\s-]'), ' ')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
}

/// Words of the normalized text, without the Arabic definite article.
List<String> tokens(String input) => normalizeText(input)
    .split(' ')
    .where((w) => w.isNotEmpty)
    .map((w) => w.startsWith('ال') && w.length > 3 ? w.substring(2) : w)
    .toList();

/// True when [phrase] appears in [text] as a sequence of whole words.
bool containsPhrase(String text, String phrase) {
  final p = tokens(phrase).join(' ');
  return p.isNotEmpty && ' ${tokens(text).join(' ')} '.contains(' $p ');
}

bool containsAny(String text, List<String> phrases) => phrases.any((p) => containsPhrase(text, p));
