import 'package:flutter/material.dart';
import '../data/store.dart';
import '../engines/answer_engine.dart';
import '../engines/question_analyzer.dart';
import '../models.dart';

class SolverScreen extends StatefulWidget {
  const SolverScreen({super.key, required this.store});
  final Store store;

  @override
  State<SolverScreen> createState() => _SolverState();
}

class _SolverState extends State<SolverScreen> {
  final _question = TextEditingController();
  final _options = TextEditingController();
  final _code = TextEditingController();
  QuestionType? _manual;
  QuestionAnalysis? _analysis;
  AnswerResult? _result;
  int? _savedId;
  bool _favorite = false;
  bool _busy = false;

  @override
  void dispose() {
    _question.dispose();
    _options.dispose();
    _code.dispose();
    super.dispose();
  }

  void _message(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  Future<void> _run() async {
    final text = _question.text.trim();
    if (text.isEmpty) return _message('اكتب السؤال أولًا');
    final input = QuestionInput(
      text: text,
      options: _options.text.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList(),
      code: _code.text.trim(),
      manualType: _manual,
    );
    final a = const QuestionAnalyzer().analyze(input);
    final r = const AnswerEngine().solve(input, a);
    setState(() {
      _analysis = a;
      _result = r;
      _savedId = null;
      _favorite = false;
      _busy = true;
    });
    try {
      final id = await widget.store.add(HistoryItem(
        question: text,
        type: a.type.label,
        domain: a.domain.label,
        status: r.status.label,
        answer: r.answer,
        explanation: r.explanation,
        createdAt: DateTime.now(),
      ));
      if (mounted) setState(() => _savedId = id);
    } catch (_) {
      if (mounted) _message('ظهرت النتيجة لكن تعذر حفظها في السجل');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _toggleFavorite() async {
    final value = !_favorite;
    try {
      await widget.store.setFavorite(_savedId!, value);
      if (mounted) setState(() => _favorite = value);
    } catch (_) {
      if (mounted) _message('تعذر حفظ السؤال');
    }
  }

  Widget _field(TextEditingController c, String label, {Key? key, bool ltr = false}) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(
          key: key,
          controller: c,
          minLines: 2,
          maxLines: 6,
          maxLength: 4000,
          textDirection: ltr ? TextDirection.ltr : null,
          decoration: InputDecoration(labelText: label, counterText: ''),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final r = _result;
    final a = _analysis;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        _field(_question, 'نص السؤال', key: const Key('question')),
        _field(_options, 'الاختيارات — كل اختيار في سطر', key: const Key('options')),
        _field(_code, 'الكود البرمجي (اختياري)', ltr: true),
        DropdownButton<QuestionType?>(
          isExpanded: true,
          value: _manual,
          items: [
            const DropdownMenuItem(value: null, child: Text('تحديد النوع تلقائيًا')),
            for (final t in QuestionType.values) DropdownMenuItem(value: t, child: Text(t.label)),
          ],
          onChanged: (v) => setState(() => _manual = v),
        ),
        const SizedBox(height: 10),
        FilledButton(onPressed: _busy ? null : _run, child: const Text('تحليل السؤال')),
        if (r != null && a != null)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('نوع السؤال: ${a.type.label}'),
                Text('المجال: ${a.domain.label}'),
                if (a.language != null) Text('اللغة: ${a.language}'),
                const Divider(),
                Text('الحالة: ${r.status.label}', style: const TextStyle(fontWeight: FontWeight.bold)),
                if (r.answer != null) SelectableText('الإجابة: ${r.answer}'),
                Text('الشرح: ${r.explanation}'),
                for (final e in r.evidence) Text('• $e'),
                if (_savedId != null)
                  TextButton.icon(
                    onPressed: _toggleFavorite,
                    icon: Icon(_favorite ? Icons.star : Icons.star_border),
                    label: Text(_favorite ? 'محفوظ' : 'حفظ السؤال'),
                  ),
              ]),
            ),
          ),
      ]),
    );
  }
}
