import 'package:flutter/material.dart';
import '../core/text.dart';
import '../data/store.dart';
import '../models.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key, required this.store});
  final Store store;

  @override
  State<HistoryScreen> createState() => _HistoryState();
}

class _HistoryState extends State<HistoryScreen> {
  String _query = '';
  bool _favoritesOnly = false;

  Future<void> _details(HistoryItem h) => showDialog<void>(
        context: context,
        builder: (d) => AlertDialog(
          title: Text(h.type),
          content: SingleChildScrollView(
            child: Text('${h.question}\n\n${h.answer ?? 'لم تُحدد إجابة'}\n\n${h.explanation}\n\n'
                '${h.createdAt.toString().substring(0, 16)}'),
          ),
          actions: [
            TextButton(
              onPressed: () async {
                Navigator.pop(d);
                await widget.store.setFavorite(h.id!, !h.favorite);
              },
              child: Text(h.favorite ? 'إلغاء الحفظ' : 'حفظ'),
            ),
            TextButton(onPressed: () => Navigator.pop(d), child: const Text('إغلاق')),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) => Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            onChanged: (v) => setState(() => _query = normalizeText(v)),
            decoration: const InputDecoration(labelText: 'بحث في السجل', prefixIcon: Icon(Icons.search)),
          ),
        ),
        FilterChip(label: const Text('المحفوظة فقط'), selected: _favoritesOnly, onSelected: (v) => setState(() => _favoritesOnly = v)),
        Expanded(
          child: ListenableBuilder(
            listenable: widget.store,
            builder: (context, _) => FutureBuilder<List<HistoryItem>>(
              future: widget.store.history(),
              builder: (context, snap) {
                if (snap.hasError) return const Center(child: Text('تعذر قراءة السجل'));
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                final items = snap.data!
                    .where((h) => (!_favoritesOnly || h.favorite) && normalizeText('${h.question} ${h.type}').contains(_query))
                    .toList();
                if (items.isEmpty) return const Center(child: Text('لا توجد عناصر'));
                return ListView.builder(
                  itemCount: items.length,
                  itemBuilder: (context, i) {
                    final h = items[i];
                    return ListTile(
                      leading: Icon(h.favorite ? Icons.star : Icons.help_outline),
                      title: Text(h.question, maxLines: 2, overflow: TextOverflow.ellipsis),
                      subtitle: Text('${h.type} • ${h.status}'),
                      onTap: () => _details(h),
                      trailing: IconButton(tooltip: 'حذف', icon: const Icon(Icons.delete_outline), onPressed: () => widget.store.delete(h.id!)),
                    );
                  },
                );
              },
            ),
          ),
        ),
      ]);
}
