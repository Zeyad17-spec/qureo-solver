import 'package:flutter/material.dart';
import '../data/store.dart';
import 'history.dart';
import 'home.dart';
import 'lessons.dart';
import 'settings.dart';
import 'solver.dart';

class ShellScreen extends StatefulWidget {
  const ShellScreen({super.key, required this.store});
  final Store store;

  @override
  State<ShellScreen> createState() => _ShellState();
}

class _ShellState extends State<ShellScreen> {
  int _index = 0;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('QUREO Solver')),
        body: IndexedStack(index: _index, children: [
          HomeScreen(store: widget.store, onSolve: () => setState(() => _index = 1)),
          SolverScreen(store: widget.store),
          const LessonsScreen(),
          HistoryScreen(store: widget.store),
          SettingsScreen(store: widget.store),
        ]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _index,
          onDestinationSelected: (v) => setState(() => _index = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.psychology_outlined), label: 'حل سؤال'),
            NavigationDestination(icon: Icon(Icons.menu_book_outlined), label: 'الدروس'),
            NavigationDestination(icon: Icon(Icons.history), label: 'السجل'),
            NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'الإعدادات'),
          ],
        ),
      );
}
